package com.example.app;

import java.util.UUID;

public class HouseHolder {
    private static String Name;
    private static String UserId;


    public static String getName() {
        return Name;
    }

    public String getUserId() {
        return UserId;
    }


    public static void setUserName(String name) {
        Name = name;
        UserId = UUID.randomUUID().toString();

    }

}

