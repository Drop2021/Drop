package com.example.app;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class infoDisplay extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.setting_page);
        infodisplay();
    }

    public void Change_Set(View v){
        Intent intent = new Intent(infoDisplay.this, change_set.class); //to acesses any item in any activity
        startActivity(intent);

    }

    public void Go2HomePage (View v){
        Intent intent = new Intent(infoDisplay.this, MainActivity.class); //to acesses any item in any activity
        startActivity(intent);
    }

    public void infodisplay(){
        TextView name = (TextView)findViewById(R.id.textView);
        TextView length = (TextView)findViewById(R.id.textView7);
        TextView width = (TextView)findViewById(R.id.textView10);
        TextView hieght = (TextView)findViewById(R.id.textView13);
        TextView ConID = (TextView)findViewById(R.id.textView12);
        name.setText("اهلاً " + HouseHolder.getName());
        length.setText(Tank.getTanklength()+"");
        width.setText(Tank.getTankwidth()+"");
        hieght.setText(Tank.getTankHeight()+"");
        ConID.setText(Board.getConfigId());

    }
}
