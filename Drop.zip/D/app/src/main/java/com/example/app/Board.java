package com.example.app;

import java.util.UUID;

public class Board {
    private static String configId;
    private static String RPId;

    public static void setboardID (String configid) { //call in set up
        configId = configid;
        RPId= UUID.randomUUID().toString();
    }

    public static String getConfigId() {
        return configId;
    }

    public static String getRPId() {
        return RPId;
    }

    public static void UpdateConfigId(String configId) { //call in change setting
        Board.configId = configId;
        //updat (RPId............)
    }


}
