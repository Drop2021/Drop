package com.example.app;

import android.content.Context;
import android.content.Intent;

public class NewActivity  extends MainActivity {
    public static void show(Context context) {
        final Intent intent = new Intent(context , set_up.class);
        context.startActivity(intent);
    }
}
