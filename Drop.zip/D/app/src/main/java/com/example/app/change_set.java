package com.example.app;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

public class change_set extends AppCompatActivity {
    double length = 0;
    double width = 0;
    double hieght = 0;
    boolean VaildWidth = false;
    boolean Vaildlength = false;
    boolean VaildHeight = false;
    boolean  VaildID = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.change_set);
        EditText lengthID = (EditText) findViewById(R.id.editTextNumber);
        EditText widthID = (EditText) findViewById(R.id.editTextNumber2);
        EditText hieghtID = (EditText) findViewById(R.id.editTextNumber3);
        EditText boardid = (EditText) findViewById(R.id.editText5);
        lengthID.setText(Tank.getTanklength()+"");
        widthID.setText(Tank.getTankwidth()+"");
        hieghtID.setText(Tank.getTankHeight()+"");
        boardid.setText(Board.getConfigId()+"");

    }


    public void Go2HomePage(View v) {
        Intent intent = new Intent(change_set.this, MainActivity.class); //to acesses any item in any activity
        startActivity(intent);

    }
    public void edit(View view){
        EditText lengthID = (EditText) findViewById(R.id.editTextNumber);///&&&&
        String lengthV = lengthID.getText().toString();
        if (lengthV.isEmpty()) {
            lengthID.setError("طول الخزان مطلوب.");
        } else {
            Vaildlength = set_up.isValidMeasure(lengthV);
            if (!Vaildlength) {
                lengthID.setError("يرجى ادخال قيمة طول صحيحه مثل 14 او رقمين بعد الفاصلة 14.30");
            }
        }
        EditText widthID = (EditText) findViewById(R.id.editTextNumber2);
        String widthtV = widthID.getText().toString();
        if (widthtV.isEmpty()) {
            widthID.setError("عرض الخزان مطلوب.");
        } else {
            VaildWidth = set_up.isValidMeasure(widthtV);
            if (!VaildWidth) {
                widthID.setError("يرجى ادخال قيمة عرض صحيحه مثل 14 او رقمين بعد الفاصلة 14.30");
            }
        }
        EditText hieghtID = (EditText) findViewById(R.id.editTextNumber3);
        String hieghtV = hieghtID.getText().toString();
        if (hieghtV.isEmpty()) {
            hieghtID.setError("ارتفاع الخزان مطلوب.");
        } else {
            VaildHeight = set_up.isValidMeasure(hieghtV);
            if (!VaildHeight) {
                hieghtID.setError("يرجى ادخال قيمة ارتفاع صحيحه مثل 14 او رقمين بعد الفاصلة 14.30");
            }
        }
        EditText boardid = (EditText) findViewById(R.id.editText5);
        String boardID = boardid.getText().toString();
        if (boardID.isEmpty()) {
            boardid.setError("يرجو منك إدخال المعرف الخاص بلوحك الذكي.");
        } else{
            VaildID = set_up.isValidID(boardID);
            if (!VaildID) {
                boardid.setError("يرجى ادخال المعرف الصحيح للوح الذكي الخاص بك");
            }
        }
        if (Vaildlength && VaildWidth && VaildHeight) {
            length = Double.parseDouble(lengthV);
            width = Double.parseDouble(widthtV);
            hieght = Double.parseDouble(hieghtV);
        }
        if (!(lengthV.isEmpty() && widthtV.isEmpty() && hieghtV.isEmpty() && boardID.isEmpty()) && VaildHeight && Vaildlength && VaildWidth && VaildID) {
             Tank.UpdateHeightWidthLength(hieght,width,length);
             Board.UpdateConfigId(boardID);

            AlertDialog dialog = new AlertDialog.Builder(change_set.this).setCancelable(true).setTitle("رسالة تأكيد ").setMessage("هل أنت/ي متأكد/ة من صحة المعلومات المدخلة وتريد/ين تخزينها في قاعدة البيانات؟").setPositiveButton("موافق", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    Intent intent = new Intent(change_set.this, infoDisplay.class);
                    startActivity(intent);
                }
            }).setNegativeButton("إلغاء", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    dialog.cancel();
                }
            }).show();
            }
        }

 }





