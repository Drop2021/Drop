package com.example.app;

import android.annotation.SuppressLint;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

public class MainActivity extends AppCompatActivity {
    public static DBHelper DB;
    private static final String CHANNEL_ID="HouseHolder";
    private static final String CHANNEL_NAME="House Holder";
    private static final String CHANNEL_DESC="HouseHolder Notification";
    public static void setFlagEmpty(boolean flagEmpty) {
        MainActivity.flagEmpty = flagEmpty;
    }
    public static boolean isFlagEmpty() {
        return flagEmpty;
    }
    static boolean flagEmpty=true;
    boolean flag = true;

    //reference for MyPreferences https://stackoverflow.com/questions/7238532/how-to-launch-activity-only-once-when-app-is-opened-for-first-time
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        DB=new DBHelper(this);
        super.onCreate(savedInstanceState);
        boolean isFirstTime = MyPreferences.isFirst(MainActivity.this);
        if (isFirstTime || flagEmpty) {
            NewActivity.show(MainActivity.this);
        }
        else {
            setContentView(R.layout.activity_main);
            if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.O){
                @SuppressLint("WrongConstant") NotificationChannel channel=new NotificationChannel(CHANNEL_ID,CHANNEL_NAME, NotificationManager.IMPORTANCE_MAX);
                channel.setDescription(CHANNEL_DESC);
                NotificationManager manager=getSystemService(NotificationManager.class);
                manager.createNotificationChannel(channel);  }
                refresh(2000);
        }
    }

    public void StateOfSensors() {
        //read from IoT
        TextView state = (TextView) findViewById(R.id.sensorsState);
        ImageView greenLamp = (ImageView) findViewById(R.id.imageView);
        ImageView redLamp = (ImageView) findViewById(R.id.imageView3);
        double distance1 = 20;
        double distance2 = 18;
        double distanceabs1;
        double distanceabs2;
        distanceabs1=Math.abs(distance1);
        distanceabs2=Math.abs(distance2);

            if ((distanceabs1-distanceabs2)<5) {
                state.setText("المستشعر يعمل بشكل جيد");
                greenLamp.setVisibility(View.VISIBLE);
                redLamp.setVisibility(View.INVISIBLE);
                flag = false;
                calculateWaterAmount(((distance1+distance2)/2));
            } else {
                state.setText("هناك خلل في المستعشر");
                greenLamp.setVisibility(View.INVISIBLE);
                redLamp.setVisibility(View.VISIBLE);
                TextView amount = (TextView) findViewById(R.id.textView5);
                amount.setText(Tank.getWaterAmount()+" لتر");
                displayNotification("المستشعر لديك يحتوي على عطل ! "," سارع بتغيير المستشعر للحصول على قراءات صحيحة ");

            }
    }

    public void WaterLevel(int level){

        }

     public void ReadTempHum(double Temp , double Hum){
     Tank.UpdateAmountTempHum(Temp,Hum);
  }

    public void calculateWaterAmount(double distance) {
        TextView amount = (TextView) findViewById(R.id.textView5);
        /* Calculate the water amount in liter*/
        double tankHeight = Tank.getTankHeight();
        double tankWidth = Tank.getTankwidth();
        double tankLength = Tank.getTanklength();
        tankHeight = set_up.convert(tankHeight);
        tankWidth = set_up.convert(tankWidth);
        tankLength = set_up.convert(tankLength);
        double distanceToWater = distance;
        double remainingWaterAmount;
        double heightOfRemainingWater;
        heightOfRemainingWater = tankHeight - distanceToWater;
        remainingWaterAmount = (tankWidth * tankLength * heightOfRemainingWater) / 1000;
        amount.setText(remainingWaterAmount + " لتر");
        Tank.setWaterAmount(remainingWaterAmount);
    }


    public void SettingPage(View view) {
        Intent intent = new Intent(MainActivity.this, infoDisplay.class); //to acesses any item in any activity
        startActivity(intent);

    }

    //reference https://stackoverflow.com/questions/3072173/how-to-call-a-method-after-a-delay-in-android
    private void refresh(int milisec) { //to refreech page after n milisec
        final Handler handler = new Handler();
        final Runnable runnable = new Runnable() {
            @Override
            public void run() {
                StateOfSensors();
            }
        };
        handler.postDelayed(runnable, milisec);
    }

    //reference https://youtu.be/sVdpslsB9qQ
    public void displayNotification(String title,String body){
        NotificationCompat.Builder mBuilder= new NotificationCompat.Builder(this,CHANNEL_ID)
                .setSmallIcon(R.drawable.ic__)
                .setContentTitle(title)
                .setContentText(body)
                .setPriority(Notification.PRIORITY_MAX);

        NotificationManagerCompat notificationManager=NotificationManagerCompat.from(this);
        notificationManager.notify(1,mBuilder.build());

    }

}





