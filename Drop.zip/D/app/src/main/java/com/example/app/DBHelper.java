package com.example.app;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

//reference https://gr8pra.wixsite.com/website-1/post/insert-delete-update-and-view-data-in-sqlite-database-android-studio
public class DBHelper extends SQLiteOpenHelper {
    public DBHelper(Context context) {
        super(context, "dropDB.db", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase DB) {
        DB.execSQL("create Table Housholders(userId TEXT primary key, householderName TEXT)");
        DB.execSQL("create Table Tanks(tankId TEXT primary key, tankHeight NUMERIC, tankLength NUMERIC, tankWidth NUMERIC, waterAmount NUMERIC, tankTemperature NUMERIC, tankHumidity NUMERIC, userId TEXT, FOREIGN KEY (userId) REFERENCES Housholders(userId) )");
        DB.execSQL("create Table raspberryPiBoards(raspberryPiBoardId TEXT primary key, configurationId TEXT,tankId TEXT, FOREIGN KEY (tankId) REFERENCES Tanks(tankId) )");
    }

    @Override
    public void onUpgrade(SQLiteDatabase DB, int i, int i1) {
        DB.execSQL("drop Table if exists Housholders");
        DB.execSQL("drop Table if exists Tanks");
        DB.execSQL("drop Table if exists raspberryPiBoards");

    }
            /*Housholders table: insert, update,delete, and get data.*/

    public boolean insertHHData (String userId ,String householderName){
        /*insert Housholder data */
        SQLiteDatabase DB = this.getWritableDatabase();
        ContentValues contentValues =new ContentValues();
        contentValues.put("userId", userId);
        contentValues.put("householderName", householderName);
        long result = DB.insert("Housholders", null ,contentValues );

        if(result==-1){
            return false;
        }else {
            return true;
        }
    }

    public boolean updateHHData (String userId ,String householderName){
        /*insert Housholder data */
        SQLiteDatabase DB = this.getWritableDatabase();
        ContentValues contentValues =new ContentValues();
        Cursor cursor= DB.rawQuery("Select * from Housholders where userId=?", new String[] {userId});

        if(cursor.getCount()>0){
        contentValues.put("userId", userId);
        contentValues.put("householderName", householderName);

        long result = DB.update("Housholders",contentValues, "userId=?" , new String[] {userId} );

        if(result==-1){
            return false;
        }else {
            return true;
        }}
        return false;}

    public boolean deleteHHData (String userId){
        /*delete Housholder data */

        SQLiteDatabase DB = this.getWritableDatabase();
        Cursor cursor= DB.rawQuery("Select * from Housholders where userId=?", new String[] {userId});

        if(cursor.getCount()>0){
            long result = DB.delete("Housholders", "userId=?", new String[] {userId});

            if(result==-1){
                return false;
            }else {
                return true;
            }
        }
        else {
            return false;
        }

    }

    public Cursor getHHData (){
        /*retrieve Housholder data */
        SQLiteDatabase DB = this.getWritableDatabase();
        Cursor cursor= DB.rawQuery("Select * from Housholders ",null);
        return cursor;
    }

    /*Tanks table: insert, update,delete, and get data.*/

    public boolean insertTankData (String tankId ,double tankHeight, double tankLength, double tankWidth,double waterAmount,double tankTemperature ,double tankHumidity ){
        /*insert tank data */
        SQLiteDatabase DB = this.getWritableDatabase();
        ContentValues contentValues =new ContentValues();
        contentValues.put("tankId", tankId);
        contentValues.put("tankHeight", tankHeight);
        contentValues.put("tankLength", tankLength);
        contentValues.put("tankWidth", tankWidth);
        contentValues.put("waterAmount", waterAmount);
        contentValues.put("tankTemperature", tankTemperature);
        contentValues.put("tankHumidity", tankHumidity);

        long result = DB.insert("Tanks", null ,contentValues );

        if(result==-1){
            return false;
        }else {
            return true;
        }
    }

    public boolean updateTankData (String tankId ,double tankHeight, double tankLength, double tankWidth ,double waterAmount,double tankTemperature ,double tankHumidity){
        /*update tank data */
        SQLiteDatabase DB = this.getWritableDatabase();
        ContentValues contentValues =new ContentValues();
        Cursor cursor= DB.rawQuery("Select * from Tanks where tankId=?", new String[] {tankId});

        if(cursor.getCount()>0){
        contentValues.put("tankHeight", tankHeight);
        contentValues.put("tankLength", tankLength);
        contentValues.put("tankWidth", tankWidth);
        contentValues.put("waterAmount", waterAmount);
        contentValues.put("tankTemperature", tankTemperature);
        contentValues.put("tankHumidity", tankHumidity);

        long result = DB.update("Tanks", contentValues , "tankId=?", new String[] {tankId});

        if(result==-1){
            return false;
        }else {
            return true;
        }
    }
        else {
            return false;
        }

    }

    public boolean deleteTankData (String tankId){
        /*delete tank data */

        SQLiteDatabase DB = this.getWritableDatabase();
        Cursor cursor= DB.rawQuery("Select * from Tanks where tankId=?", new String[] {tankId});

        if(cursor.getCount()>0){
            long result = DB.delete("Tanks", "tankId=?", new String[] {tankId});

            if(result==-1){
                return false;
            }else {
                return true;
            }
        }
        else {
            return false;
        }

    }

    public Cursor getTankData (){
        /*retrieve tank data */
        SQLiteDatabase DB = this.getWritableDatabase();
        Cursor cursor= DB.rawQuery("Select * from Tanks ",null);
        return cursor;
    }

    public Cursor getWaterAmount (String tankId){
        /*retrieve tank data */
        SQLiteDatabase DB = this.getWritableDatabase();
        Cursor cursor= DB.rawQuery("Select waterAmount from Tanks   where tankId=?", new String[] {tankId});
        return cursor;
    }


    /*raspberryPiBoards table: insert, update,delete, and get data.*/

    public boolean insertBoardData (String raspberryPiBoardId ,String configurationId){
        /*insert raspberry pi boards data */
        SQLiteDatabase DB = this.getWritableDatabase();
        ContentValues contentValues =new ContentValues();
        contentValues.put("raspberryPiBoardId", raspberryPiBoardId);
        contentValues.put("configurationId", configurationId);
        long result = DB.insert("raspberryPiBoards", null ,contentValues );

        if(result==-1){
            return false;
        }else {
            return true;
        }
    }

    public boolean updateBoardData (String raspberryPiBoardId ,String configurationId){
        /*insert raspberry pi boards data */
        SQLiteDatabase DB = this.getWritableDatabase();
        ContentValues contentValues =new ContentValues();
        Cursor cursor= DB.rawQuery("Select * from raspberryPiBoards where raspberryPiBoardId=?", new String[] {raspberryPiBoardId});

        if(cursor.getCount()>0){
            contentValues.put("raspberryPiBoardId", raspberryPiBoardId);
            contentValues.put("configurationId", configurationId);

            long result = DB.update("raspberryPiBoards",contentValues, "raspberryPiBoardId=?" , new String[] {raspberryPiBoardId} );

            if(result==-1){
                return false;
            }else {
                return true;
            }}
        return false;}

    public boolean deleteBoardData (String raspberryPiBoardId){
        /*delete raspberry pi boards  data */

        SQLiteDatabase DB = this.getWritableDatabase();
        Cursor cursor= DB.rawQuery("Select * from raspberryPiBoards where raspberryPiBoardId=?", new String[] {raspberryPiBoardId});

        if(cursor.getCount()>0){
            long result = DB.delete("raspberryPiBoards", "raspberryPiBoardId=?", new String[] {raspberryPiBoardId});

            if(result==-1){
                return false;
            }else {
                return true;
            }
        }
        else {
            return false;
        }

    }

    public Cursor getBoardData (){
        /*retrieve raspberry pi boards data */
        SQLiteDatabase DB = this.getWritableDatabase();
        Cursor cursor= DB.rawQuery("Select * from raspberryPiBoards ",null);
        return cursor;
    }

}
