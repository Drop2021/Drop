package com.example.app;


import static com.example.app.MainActivity.DB;

import java.util.UUID;

public class Tank {
    private static double TankHeight;
    private static double Tankwidth;
    private static double Tanklength;
    private static double TankTemperture;
    private static double TankHumedity;

    public static double getWaterAmount() {
        return WaterAmount;
    }

    private static double WaterAmount;
    private static String TankId;
    private static Boolean isFirst=true;
    private static double MaxAmount;

    public static double getTankHeight() {
        return TankHeight;
    }

    public static double getTankwidth() {
        return Tankwidth;
    }

    public static double getTanklength() {
        return Tanklength;
    }

    public static void setWaterAmount(double waterAmount) {
        WaterAmount = waterAmount;
    }


    public static void setterHeightWidthLength (double tankHeight , double tankwidth , double tanklength){ //call in set up
        TankHeight = tankHeight;
        Tankwidth = tankwidth;
        Tanklength = tanklength;
        TankId = UUID.randomUUID().toString();
        isFirst=false;
        MaxAmount=tankHeight*tankwidth*tanklength;
        DB.insertTankData (TankId , TankHeight, Tanklength , Tankwidth, 0 ,0 ,0);

    }

    public static void UpdateHeightWidthLength (double tankHeight , double tankwidth , double tanklength){
        TankHeight = tankHeight;
        Tankwidth = tankwidth;
        Tanklength = tanklength;
        DB.insertTankData (TankId , TankHeight, Tanklength , Tankwidth, WaterAmount ,TankTemperture ,TankHumedity);
        //update (TankID,........)

    }

    public static void UpdateAmountTempHum (double temp ,double hum){
        TankTemperture=temp;
        TankHumedity=hum;
        DB.insertTankData (TankId , TankHeight, Tanklength , Tankwidth, WaterAmount ,TankTemperture ,TankHumedity);
    }


    public static double getMaxAmount() {
        return MaxAmount;
    }

    public static void setMaxAmount(double maxAmount) {
        MaxAmount = maxAmount;
    }

}





