package com.example.app;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class set_up extends AppCompatActivity {
    double length = 0;
    double width = 0;
    double hieght = 0;
    boolean VaildWidth = false;
    boolean Vaildlength = false;
    boolean VaildHeight = false;
    boolean  VaildID = false;
    static boolean flag=true;
    AlertDialog dialog;
    boolean sure=false;
    public static boolean isFlag() {
        return flag;
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.set_up_page);
    }

    public void info(View view){
             EditText nameID = (EditText)findViewById(R.id.editText4);
             String Name = nameID.getText().toString();
               if (Name.isEmpty()) {
               nameID.setError("يرجو منك ادخال اسمك.");
             }
            EditText lengthID = (EditText) findViewById(R.id.editText);///&&&&
            String lengthV = lengthID.getText().toString();
            if (lengthV.isEmpty()) {
                lengthID.setError("طول الخزان مطلوب.");
            } else {
                Vaildlength = set_up.isValidMeasure(lengthV);
                if (!Vaildlength) {
                    lengthID.setError("يرجى ادخال قيمة طول صحيحه مثل 14 او رقمين بعد الفاصلة 14.30");
                }
            }
            EditText widthID = (EditText) findViewById(R.id.textInputEditText);
            String widthtV = widthID.getText().toString();
            if (widthtV.isEmpty()) {
                widthID.setError("عرض الخزان مطلوب.");
            } else {
                VaildWidth = set_up.isValidMeasure(widthtV);
                if (!VaildWidth) {
                    widthID.setError("يرجى ادخال قيمة عرض صحيحه مثل 14 او رقمين بعد الفاصلة 14.30");
                }
            }
            EditText hieghtID = (EditText) findViewById(R.id.editText2);
            String hieghtV = hieghtID.getText().toString();
            if (hieghtV.isEmpty()) {
                hieghtID.setError("ارتفاع الخزان مطلوب.");
            } else {
                VaildHeight = set_up.isValidMeasure(hieghtV);
                if (!VaildHeight) {
                    hieghtID.setError("يرجى ادخال قيمة ارتفاع صحيحه مثل 14 او رقمين بعد الفاصلة 14.30");
                }
            }
            EditText boardid = (EditText) findViewById(R.id.editText3);
            String boardID = boardid.getText().toString();
            if (boardID.isEmpty()) {
                boardid.setError("يرجو منك إدخال المعرف الخاص بلوحك الذكي.");
            } else{
                VaildID = set_up.isValidID(boardID);
                if (!VaildID) {
                    boardid.setError("يرجى ادخال المعرف الصحيح للوح الذكي الخاص بك");
                }
            }
            if (Vaildlength && VaildWidth && VaildHeight) {
                length = Double.parseDouble(lengthV);
                width = Double.parseDouble(widthtV);
                hieght = Double.parseDouble(hieghtV);
            }
            if (!(lengthV.isEmpty() && widthtV.isEmpty() && hieghtV.isEmpty() && boardID.isEmpty()) && VaildHeight && Vaildlength && VaildWidth && VaildID) {
                Tank.UpdateHeightWidthLength(hieght,width,length);
                Board.UpdateConfigId(boardID);

                //reference https://www.youtube.com/watch?v=men8GB-7yM0
                AlertDialog dialog = new AlertDialog.Builder(set_up.this).setCancelable(true).setTitle("رسالة تأكيد ").setMessage("هل أنت/ي متأكد/ة من صحة المعلومات المدخلة وتريد/ين تخزينها في قاعدة البيانات؟").setPositiveButton("موافق", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        MainActivity.setFlagEmpty(false);
                        Tank.setterHeightWidthLength(hieght, width, length);
                        Board.setboardID(boardID);
                        HouseHolder.setUserName(Name);
                        Intent intent = new Intent(set_up.this, MainActivity.class);
                        startActivity(intent);
                    }
                }).setNegativeButton("إلغاء", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                }).show();
            }
        }


    public static boolean isValidMeasure(final String measure) {
        Pattern pattern;
        Matcher matcher;

        final String measure_PATTERN = "([1-9]+[0-9]*((\\.\\d{2})?))$";
        pattern = Pattern.compile(measure_PATTERN);
        matcher = pattern.matcher(measure);

        return matcher.matches();
    }

    public static boolean isValidID(final String ID) {

        Pattern pattern;
        Matcher matcher;

        final String ID_PATTERN = "^[A-Za-z0-9]+$";
        pattern = Pattern.compile(ID_PATTERN);
        matcher = pattern.matcher(ID);

        return matcher.matches();
    }

    public static double convert(double number) {
        return number * 100; //to covert to cm
    }


}