package com.example.app;

import static com.example.app.set_up.DB;

import android.annotation.SuppressLint;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.os.Build;
import android.os.IBinder;
import android.util.Base64;
import android.util.Log;

import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;

import org.joda.time.DateTime;
import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;

public class Background_Service extends Service {
    private static final String CHANNEL_ID="HouseHolder";
    private static final String CHANNEL_NAME="House Holder";
    private static final String CHANNEL_DESC="HouseHolder Notification";
    static String TAG = "App";
    static double [] Distance1 = new double[2];
    static double[] Distance2 = new double[2];
    static boolean DisConnection=false;
    static double[] Level = new double[2];
    static double distance1;
    static double distance2;
    static boolean isFinished = false; //is the all varible set or not?
    static boolean isValidID = true;
    static boolean setDis1 = false;
    static boolean setDis2 = false;
    static boolean setLevel = false;
    static boolean setCons = false;
    static boolean setQual=false;
    static double remainingWaterAmount = 0;
    static double [] WaterQuality = new double[2];
    static double [] WaterCons =  new double[2];
    static double dailyCons;
    static double waterQual=0;
    static int level=0;
    int i=0;
    public String source;
    int length=0; //to see if there a new reading of the water flow we receive or no
    int tmp = 0; //to save the previous length
    double averageDis;


    @Override
    public void onCreate() {
        super.onCreate();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            @SuppressLint("WrongConstant") NotificationChannel channel = new NotificationChannel(CHANNEL_ID, CHANNEL_NAME, NotificationManager.IMPORTANCE_MAX);
            channel.setDescription(CHANNEL_DESC);
            NotificationManager manager = getSystemService(NotificationManager.class);
            manager.createNotificationChannel(channel);
        }
        Log.d("Start-Service","The service is created!");
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Background();
        return START_STICKY;
    }

    public void Background() {
        //to repeated every 10000 ms
                long INTERVAL_MSEC = 10000;
                Timer timer = new Timer();
                TimerTask task = new TimerTask() {
                    public void run() {
                        source = PreferenceUtils.getBoardId(Background_Service.this); //take Conf ID from shared
                        isFinished=false;
                        GetData("c8y_Distance1.D1", 0);
                        GetData("c8y_Distance2.D2", 1);
                        GetData("c8y_Level.L", 2);
                        GetData("c8y_Consumption.C", 3);
                        GetData("c8y_Quality.Q", 4);
                        //GetData();
                    }
                }; timer.scheduleAtFixedRate(task, 0, INTERVAL_MSEC);

                long INTERVAL_MSEC2 = 1800000;
                 Timer timer2 = new Timer();
                 TimerTask task2 = new TimerTask() {
                   public void run() {
                            i=0;
                  }
                 }; timer.scheduleAtFixedRate(task2, 0, INTERVAL_MSEC2);

    }


    public void WaterLevel(){ //when the water level is less than a quarter of the tank height
        level= (int) Level[1];
        if(level==1){
            displayNotification(" كمية المياة في خزانك قليلة ! ", "سارع في تعبئة خزانك" , Background_Service.this);
        }
    }

    public void Connection(){ //when the wifi of the mobile phone disconnected
        if(DisConnection){
            displayNotification("تأكد من إتصالك بالإنترنت ! ", "سارع بالإتصال بالإنترنت حتى تحصل على كمية المياة لديك " , Background_Service.this);
        }
    }

    public void calculateWaterAmount() { //to calculater water amount in the tank
        averageDis = 0;
        distance1 = Distance1[1];
        distance2 = Distance2[1];
        if (distance1 - distance2 > 5) {
            Background_Service.displayNotification("الحساس لديك يحتوي على عطل ! ", " سارع بتغيير الحساس للحصول على قراءات صحيحة " , Background_Service.this);
        } else {
            averageDis = (distance1 + distance2) / 2;
            /* Calculate the water amount in liter*/
            double tankHeight = Tank.getTankHeight(this);
            double tankWidth = Tank.getTankwidth(this);
            double tankLength = Tank.getTanklength(this);

            //here just we remove for our demo
//            tankHeight = set_up.convert(tankHeight);
//            tankWidth = set_up.convert(tankWidth);
//            tankLength = set_up.convert(tankLength);

            double distanceToWater = averageDis;
            double heightOfRemainingWater = tankHeight - distanceToWater ;
            if (heightOfRemainingWater != 0) {
                // commented for the demo (demo will be in liter)=> remainingWaterAmount = (tankWidth * tankLength * heightOfRemainingWater) / 1000000; /* to calculate the amount in cubic meter*/
                remainingWaterAmount = Math.round((tankWidth * tankLength * heightOfRemainingWater / 1000));
            }
            isFinished = true;

        }
    }

    public void calcDailyCons ( ) {
        /* calcuates today's consumption */
        double oldCons=0;

        /* get last inserted consumption */
        Cursor consCursor = DB.getDailyCons(PreferenceUtils.getTankID(this));
        if (consCursor.getCount() != 0) {
            while (consCursor.moveToNext()) {
                oldCons = Double.parseDouble(consCursor.getString(0));
            }
        }//end if
        else {
            oldCons=WaterCons[1];
        }
           if(tmp==length){ //to check if we not receive new cons reading
               return;
           }

           else {
               tmp=length;
               if (isNewDay()) {
                   dailyCons = WaterCons[1];
               } else {
                   dailyCons = oldCons + WaterCons[1];
               }
           }
        }


    //the accepted value of water quality we  take it from https://quenchwater.com/blog/tds-in-drinking-water/
    public void waterQuality(){
        waterQual=WaterQuality[1];
       if (waterQual>1200){
           displayNotification("جودة المياة في خزانك سيئة ! ", "تحقق من جودة المياة لديك" , Background_Service.this);
       }
    }

    public static void displayNotification(String title, String body , Context context){
        NotificationCompat.Builder mBuilder= new NotificationCompat.Builder(context,CHANNEL_ID)
                .setSmallIcon(R.drawable.ic__)
                .setContentTitle(title)
                .setContentText(body)
                .setPriority(Notification.PRIORITY_MAX);

        NotificationManagerCompat notificationManager=NotificationManagerCompat.from(context);
        notificationManager.notify(1,mBuilder.build());

    }




    public void GetData(String measurementName, int address){
        DisConnection=false;
        setDis1=false;
        setDis2=false;
        setLevel=false;
        setQual=false;
        setCons=false;
        String tag_string_req = "req_login";
        DateTime today = new DateTime();
        DateTime after2day = today.plusDays(2); //becuase the server of IoT platform not in our country
        String currentDay = today.getYear()+"-"+today.getMonthOfYear()+"-"+today.getDayOfMonth();
        String DayOfServer = after2day.getYear()+"-"+after2day.getMonthOfYear()+"-"+after2day.getDayOfMonth();


        StringRequest strReq = new StringRequest(Request.Method.GET, "https://iotccis21.cumulocity.com/measurement/measurements/series?series=" + measurementName + "&source=" + source + "&dateFrom=" + currentDay + "&dateTo="+ DayOfServer, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    isValidID=true;
                    DisConnection=false;
                    JSONObject jObj = new JSONObject(response);
                    JSONObject a = jObj.getJSONObject("values");
                    JSONArray c = a.names();
                    if(address==3){
                        length=c.length();
                    }
                    String lastMeasurement = c.get(c.length() - 1).toString();
                    JSONArray b = a.getJSONArray(lastMeasurement);

                    double min = Double.parseDouble(String.valueOf(b.getJSONObject(0).get("min")));
                    double max = Double.parseDouble(String.valueOf(b.getJSONObject(0).get("max")));

                    switch (address){
                        case 0:
                            Distance1[0]=min;
                            Distance1[1]=max;
                            setDis1=true;
                            Log.d(TAG, Distance1[0] +" Distance 1 " + Distance1[1] + setDis1 );
                            break;
                        case 1:
                            Distance2[0]=min;
                            Distance2[1]=max;
                            setDis2=true;
                            Log.d(TAG, Distance2[0] +" Distance 2 " + Distance2[1] +setDis2 );
                            break;
                        case 2:
                            Level[0]=min;
                            Level[1]=max;
                            setLevel=true;
                            Log.d(TAG, Level[0] +" Level " + Level[1] + setLevel);
                            break;
                        case 3:
                            WaterCons[0]=min;
                            WaterCons[1]=max;
                            setCons=true;
                            Log.d(TAG, WaterCons[0] +" Cons " + WaterCons[1] + setCons);
                            break;
                        case 4:
                            WaterQuality[0]=min;
                            WaterQuality[1]=max;
                            setQual=true;
                            Log.d(TAG, WaterQuality[0] +" Quality " + WaterQuality[1] + setQual);
                            break;
                    }

                    if(setDis1==true&&setDis2==true&&setLevel==true&&setCons==true&&setQual==true) {
                        calculateWaterAmount();
                        waterQuality();
                        calcDailyCons();
                        UpdateDataBase();
                        WaterLevel();
                    }

                } catch (Exception e) {
                    // JSON error
                    e.printStackTrace();
                    Log.d(TAG, "CATCH-ERORRR");
                    isValidID=false;
                    isFinished=true;
                    DisConnection=false;
                    if (i == 0) {
                        displayNotification("تأكد من المعرف الخاص بك ! " ," في حالة المعرف الخاص بك صحيح تواصل مع الدعم الفني لإضافته في المنصة ", Background_Service.this);
                        i++;
                    }
                }
            }
        }, new Response.ErrorListener() {

            public void onErrorResponse(VolleyError error) {
                Log.e(TAG, "Login Error: " + error.getMessage());
                DisConnection=true;
                isFinished=true;
                //check it again
                if(i==0){
                    Connection();
                    i++;
                }
            }
        }){
            @Override
            public Map<String , String > getHeaders() throws AuthFailureError {
                String credentials = "439200783@student.ksu.edu.sa" + ":" + "Mnoor2579";
                String base64Encoded = Base64.encodeToString(credentials.getBytes() , Base64.NO_WRAP);
                Map<String, String> headers = new HashMap<String, String>();
                headers.put("Content-Type" , "Application/json");
                headers.put("Authorization" , "Basic " + base64Encoded);
                return headers;
            }
        };

        // Adding request to request queue
        strReq.setShouldCache(false);
        AppController.getInstance().addToRequestQueue(strReq, tag_string_req);


    }


    public boolean isNewDay(){
        /* returns true if it is a new day and false if not */
        SimpleDateFormat format = new SimpleDateFormat( "yyyy-MM-dd");
        Calendar cal = Calendar.getInstance() ;
        String currentDay = format.format(cal.getTime());
        Log.d("Day" , currentDay);
        String pdate ="";

        /* get last date a row was inserted */
        Cursor dateCursor= DB.getLastDate(PreferenceUtils.getTankID(Background_Service.this));

        if (dateCursor.getCount() != 0) {
            while (dateCursor.moveToNext()){
                pdate = dateCursor.getString(0);
            }
        }//end if

        else {
            //no have field in the database which mean its the first day of using the app
            return true;
        }
        /* get current date */

        if(!currentDay.equals(pdate) ){
            return true;
        }
        else{
            return false;
        }

    }

    public void UpdateDataBase(){
        if(isNewDay()){
            SimpleDateFormat format = new SimpleDateFormat( "yyyy-MM-dd");
            Calendar cal = Calendar.getInstance() ;
            String currentDay = format.format(cal.getTime());
         Water_State.insertWaterState(remainingWaterAmount,  dailyCons,  waterQual,  currentDay , Background_Service.this);
        }
        else{
        Water_State.updateWaterState(remainingWaterAmount,  dailyCons, waterQual, Background_Service.this);
        }
    }


    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.d("Stop-Service" , "The service is stoped!");
    }
}


