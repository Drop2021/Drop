package com.example.app;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class infoDisplay extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.infodisplaymobile);
        infodisplay();
    }

    public void Change_Set(View v){
        Intent intent = new Intent(infoDisplay.this, change_set.class); //to acesses any item in any activity
        startActivity(intent);

    }

    public void Go2HomePage (View v){
        Intent intent = new Intent(infoDisplay.this, MainActivity.class); //to acesses any item in any activity
        startActivity(intent);
    }

    public void infodisplay(){
        TextView name = findViewById(R.id.textView);
        TextView length = findViewById(R.id.textView7);
        TextView width =  findViewById(R.id.textView10);
        TextView hieght = findViewById(R.id.textView13);
        TextView ConID = findViewById(R.id.textView12);
        name.setText("اهلاً " + HouseHolder.getName(infoDisplay.this));
        length.setText(Tank.getTanklength(infoDisplay.this)+"");
        width.setText(Tank.getTankwidth(infoDisplay.this)+"");
        hieght.setText(Tank.getTankHeight(infoDisplay.this)+"");
        ConID.setText(Board.getConfigId(infoDisplay.this));
    }
}
