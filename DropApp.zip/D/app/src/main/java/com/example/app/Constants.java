package com.example.app;

public class Constants {
    public static String KEY_Height = "Height";
    public static String KEY_Width = "Width";
    public static String KEY_Length = "Length";
    public static String KEY_Name= "Name";
    public static String KEY_Rbid = "ID";
    public static String KEY_Rid = "RID";
    public static String KEY_FIRST = "false";
    public static String KEY_TankID ="0";
    public static String KEY_UserID ="0";
    public static String KEY_WaterStateId ="WSid";

}
