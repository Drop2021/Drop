package com.example.app;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.util.Timer;
import java.util.TimerTask;

public class MainActivity extends AppCompatActivity{
    //public static DBHelper DB ;
    BottomNavigationView bottomNavigationView;
    static boolean isChange = false;
    static boolean isFirst = true;
    static TextView state;
    static ImageView green;
    static ImageView con; //connection
    static ImageView goodQual;
    static ImageView poorQual;
    static ImageView badQual;
    static ImageView redLamp;
    static TextView amount;
    static ProgressBar prog;
    static ProgressBar prog2;
    static TextView quality;
    static TextView textquality;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        prog = findViewById(R.id.progress_loader1);
        prog2 = findViewById(R.id.progress_loader2);
        state = findViewById(R.id.sensorsState);
        green = findViewById(R.id.imageView);
        con = findViewById(R.id.imageView2);
        redLamp = findViewById(R.id.imageView3);
        goodQual = findViewById(R.id.imageView4);
        poorQual = findViewById(R.id.imageView5);
        badQual =  findViewById(R.id.imageView7);
        amount =  findViewById(R.id.textView5);
        quality = findViewById(R.id.textView11);
        textquality = findViewById(R.id.textView40);
        bottomNavigationView = findViewById(R.id.bottom_nav);
        bottomNavigationView.setSelectedItemId(R.id.Home);
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.Analysis:
                        startActivity(new Intent(MainActivity.this, Analysis.class));
                        overridePendingTransition(0, 0);
                        return true;
                    case R.id.Home:
                        return true;
                }
                return false;
            }
        });

        //to repeated every 18000 ms
        long INTERVAL_MSEC = 18000;
        Timer timer = new Timer();
        TimerTask task = new TimerTask() {
            public void run() {
                if (!Background_Service.isFinished) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            quality.setVisibility(View.INVISIBLE);
                            textquality.setVisibility(View.INVISIBLE);
                            state.setVisibility(View.INVISIBLE);
                            con.setVisibility(View.INVISIBLE);
                            green.setVisibility(View.INVISIBLE);
                            goodQual.setVisibility(View.INVISIBLE);
                            poorQual.setVisibility(View.INVISIBLE);
                            badQual.setVisibility(View.INVISIBLE);
                            redLamp.setVisibility(View.INVISIBLE);
                            amount.setVisibility(View.INVISIBLE);
                            prog.setVisibility(View.VISIBLE);
                            prog2.setVisibility(View.VISIBLE);
                        }
                    });
                } else {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            DisplayInfo();
                        }
                    });

                }
            }
        }; timer.scheduleAtFixedRate(task, 0, INTERVAL_MSEC);


    }




    public void DisplayInfo() {
        //read from IoT
        prog.setVisibility(View.INVISIBLE);
        prog2.setVisibility(View.INVISIBLE);
        double distance1 = Background_Service.Distance1[1];
        double distance2 = Background_Service.Distance2[1];
        double distanceabs1;
        double distanceabs2;
        distanceabs1=Math.abs(distance1);
        distanceabs2=Math.abs(distance2);

        if (Background_Service.DisConnection==true){
        state.setText("تحقق من اتصالك بالإنترنت");
        state.setVisibility(View.VISIBLE);
        con.setVisibility(View.VISIBLE);
        green.setVisibility(View.INVISIBLE);
        redLamp.setVisibility(View.INVISIBLE);
        goodQual.setVisibility(View.INVISIBLE);
        poorQual.setVisibility(View.INVISIBLE);
        badQual.setVisibility(View.INVISIBLE);
        amount.setText( " تحقق من اتصالك بالإنترنت ");
        amount.setVisibility(View.VISIBLE);
        quality.setVisibility(View.INVISIBLE);
        } else if (Background_Service.isValidID==false) {
            state.setText("تحقق من المعرف الخاص بك");
            state.setVisibility(View.VISIBLE);
            green.setVisibility(View.INVISIBLE);
            redLamp.setVisibility(View.VISIBLE);
            goodQual.setVisibility(View.INVISIBLE);
            poorQual.setVisibility(View.INVISIBLE);
            badQual.setVisibility(View.INVISIBLE);
            con.setVisibility(View.INVISIBLE);
            amount.setText(" تحقق من المعرف الخاص بك ");
            amount.setVisibility(View.VISIBLE);
            quality.setVisibility(View.INVISIBLE);

        } else if ((distanceabs1 - distanceabs2) < 5) {
            state.setText("الحسـاس يعمل بشكل جيد");
            state.setVisibility(View.VISIBLE);
            green.setVisibility(View.VISIBLE);
            con.setVisibility(View.INVISIBLE);
            redLamp.setVisibility(View.INVISIBLE);
            amount.setVisibility(View.VISIBLE);
            amount.setText(Background_Service.remainingWaterAmount + " لتر");

            if(Background_Service.setQual&&Background_Service.remainingWaterAmount==0){
                quality.setVisibility(View.INVISIBLE);
                goodQual.setVisibility(View.INVISIBLE);
                poorQual.setVisibility(View.INVISIBLE);
                badQual.setVisibility(View.INVISIBLE);
            }

            else if(Background_Service.setQual&&Background_Service.waterQual<900){
                quality.setVisibility(View.VISIBLE);
                quality.setTextColor(Color.parseColor("#00B948"));
                textquality.setVisibility(View.VISIBLE);
                quality.setText("جيدة");
                goodQual.setVisibility(View.VISIBLE);
                poorQual.setVisibility(View.INVISIBLE);
                badQual.setVisibility(View.INVISIBLE);
            }else if(Background_Service.setQual&&(Background_Service.waterQual>=900&&Background_Service.waterQual<=1200)) {
                quality.setVisibility(View.VISIBLE);
                quality.setTextColor(Color.parseColor("#FFA500"));
                textquality.setVisibility(View.VISIBLE);
                quality.setText("منخفضة");
                goodQual.setVisibility(View.INVISIBLE);
                poorQual.setVisibility(View.VISIBLE);
                badQual.setVisibility(View.INVISIBLE);
            } else if (Background_Service.setQual&&Background_Service.waterQual>1200){
                quality.setVisibility(View.VISIBLE);
                quality.setTextColor(Color.parseColor("#FF0000"));
                textquality.setVisibility(View.VISIBLE);
                quality.setText("سيئـة");
                goodQual.setVisibility(View.INVISIBLE);
                poorQual.setVisibility(View.INVISIBLE);
                badQual.setVisibility(View.VISIBLE);
                Background_Service.displayNotification("جودة المياة في خزانك سيئة ! ", "تحقق من جودة المياة لديك" , MainActivity.this);
            }

        } else {
            state.setText("هناك خلل في الحساس!");
            state.setVisibility(View.VISIBLE);
            green.setVisibility(View.INVISIBLE);
            redLamp.setVisibility(View.VISIBLE);
            goodQual.setVisibility(View.INVISIBLE);
            poorQual.setVisibility(View.INVISIBLE);
            badQual.setVisibility(View.INVISIBLE);
            con.setVisibility(View.INVISIBLE);
            amount.setText(" هناك خلل في الحساس! ");
            amount.setVisibility(View.VISIBLE);
            quality.setVisibility(View.INVISIBLE);
            Background_Service.displayNotification("الحساس لديك يحتوي على عطل ! ", " سارع بتغيير الحساس للحصول على قراءات صحيحة " , MainActivity.this);
        }
    }



    public void SettingPage(View view) {
        Intent intent = new Intent(MainActivity.this, infoDisplay.class); //to acesses any item in any activity
        startActivity(intent);
    }


}








