package com.example.app;

import static com.example.app.set_up.DB;

import android.content.Context;

import java.util.UUID;

public class Water_State {
    private static double WaterAmount;
    private static double WaterCons;
    private static double WaterQuality;
    private static String Date;

    public static String getWaterStateId(Context context) {
        return PreferenceUtils.getWSID(context);
    }

    private static String WaterStateId;


    public static void insertWaterState(double waterAmount, double waterCons, double waterQua, String date ,Context context) { //call in set up
        WaterStateId = UUID.randomUUID().toString();
        WaterAmount = waterAmount;
        WaterCons = waterCons;
        WaterQuality = waterQua;
        Date = date;
        PreferenceUtils.saveWSID(WaterStateId,context);
        DB.insertWaterState(WaterStateId,WaterAmount,WaterCons,WaterQuality,Date,Tank.getTankId(context));

    }

    public static void updateWaterState(double waterAmount, double waterCons, double waterQua ,Context context) {
        WaterAmount = waterAmount;
        WaterCons = waterCons;
        WaterQuality = waterQua;
        DB.updateWaterState(WaterStateId,WaterAmount,WaterCons,WaterQuality);
    }


}
