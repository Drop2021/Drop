package com.example.app;

import static com.example.app.set_up.DB;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.RadioButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.text.SimpleDateFormat;
import java.util.Calendar;

public class Analysis extends AppCompatActivity {
    BottomNavigationView bottomNavigationView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.analysis);
        bottomNavigationView = findViewById(R.id.bottom_nav);
        bottomNavigationView.setSelectedItemId(R.id.Analysis);
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.Analysis:
                        return true;

                    case R.id.Home:
                        startActivity(new Intent(Analysis.this, MainActivity.class));
                        overridePendingTransition(0, 0);
                        return true;
                }
                return false;
            }
        });
    }

    public void compare(View view) {
        RadioButton cons = findViewById(R.id.radioButton);
        cons.setChecked(false);
        TextView comp = findViewById(R.id.textView05);
        double lastmonthConsumption=0;
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM");
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.MONTH, -1);
        String lastmonth= format.format(cal.getTime());//last month
        Calendar cal1 = Calendar.getInstance();
        cal1.setTime(cal.getTime());
        int LMNumberOfDays=cal1.getActualMaximum(Calendar.DATE);
        String firstday=lastmonth+"-1";
        String lastday=lastmonth+"-"+LMNumberOfDays;
        Cursor x =DB.getMonthlyCons(firstday,lastday);
        if (x.getCount() != 0) {
            while (x.moveToNext()) {
                Log.d("con", x.getString(0));
                String monthly = x.getString(0);
                lastmonthConsumption += Double.parseDouble(monthly);
            }//end while
        }//end if
        double CurrentMonthConsumption = calcMonthlyCons();
        double Comparsion=lastmonthConsumption-CurrentMonthConsumption;
        double absConsm = Math.abs(Comparsion);

        if (Comparsion<0){
            //remove it just for our demo   comp.setText("زاد استهلاكك للمياة بمقدار "+ absConsm + " متر مكعب");
         comp.setText("زاد استهلاكك للمياة بمقدار "+ absConsm + " لتـر");
        } else if(Comparsion==0){
            //remove it just for our demo   comp.setText("استهلاكك للمياة لم يتغيـر "+ CurrentMonthConsumption + " متر مكعب");
            comp.setText("استهلاكك للمياة لم يتغيـر "+ CurrentMonthConsumption + " لتـر");
        } else {
            //remove it just for our demo   comp.setText("قل استهلاكك للمياة بمقدار "+ absConsm + " متر مكعب");
          comp.setText("قل استهلاكك للمياة بمقدار "+ absConsm + " لتـر");
        }
    }

    public void consumption(View view) {
        RadioButton comp = findViewById(R.id.radioButton2);
        comp.setChecked(false);
        TextView cons = findViewById(R.id.textView05);
        String  Consumption = calcMonthlyCons()+"";

        //we remove it just for our demo    cons.setText("كمية استهلاكك للشهر الحالي "+ Consumption +" متر مكعب");
        cons.setText("كمية استهلاكك للشهر الحالي "+ Consumption +" لتـر");
    }

    public void SettingPage(View view) {
        Intent intent = new Intent(Analysis.this, infoDisplay.class); //to acesses any item in any activity
        startActivity(intent);
    }

    public double calcMonthlyCons() {
        /* calcuates current month's consumption */
        Log.d("Here" , " I'm in Monthly cons ");
        double currentMonthCons = 0;

        SimpleDateFormat format = new SimpleDateFormat( "yyyy-MM-dd");
        Calendar cal = Calendar.getInstance() ;
        String currentDay = format.format(cal.getTime()) ;

        format = new SimpleDateFormat( "yyyy-MM");
        String firstDay = format.format(cal.getTime())+"-01" ;

        Cursor x =DB.getMonthlyCons(firstDay, currentDay) ;
        if (x.getCount() != 0) {
            while (x.moveToNext()){
                Log.d("con", x.getString(0));
                String monthly = x.getString(0);
                currentMonthCons += Double.parseDouble(monthly);
            }
        }//end if

        return currentMonthCons;
    }


}
