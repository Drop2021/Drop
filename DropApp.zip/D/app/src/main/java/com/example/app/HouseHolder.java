package com.example.app;

import static com.example.app.set_up.DB;

import android.content.Context;
import android.util.Log;

import java.util.UUID;

public class HouseHolder {
    private static String Name;
    private static String UserId;


    public static String getName(Context context) {
        return PreferenceUtils.getName(context);
    }

    public static String getUserId(Context context) {
        return PreferenceUtils.getUserID(context);
    }


    public static void setUserName(String name , Context context) {
        Name = name;
        UserId = UUID.randomUUID().toString();
        PreferenceUtils.saveName(Name , context);
        PreferenceUtils.saveUserID(UserId , context);
        Log.d("my data" , UserId +"-"+ Name);
        DB.insertHHData (UserId , Name);

    }

}

