package com.example.app;

import static com.example.app.set_up.DB;

import android.content.Context;

import java.util.UUID;

public class Tank {
    private static double TankHeight;
    private static double Tankwidth;
    private static double Tanklength;
    private static String TankId;



    public static String getTankId(Context context) {
        return PreferenceUtils.getTankID(context);
    }

    public static double getTankHeight(Context context) {
        TankHeight=Double.parseDouble(PreferenceUtils.getHeight(context));
        return TankHeight;
    }

    public static double getTankwidth(Context context) {
        Tankwidth=Double.parseDouble(PreferenceUtils.getWidth(context));
        return Tankwidth;
    }

    public static double getTanklength(Context context) {
        Tanklength=Double.parseDouble(PreferenceUtils.getLength(context));
        return Tanklength;
    }


    public static void setterHeightWidthLength(double tankHeight, double tankwidth, double tanklength, Context context) { //call in set up
        TankHeight = tankHeight;
        Tankwidth = tankwidth;
        Tanklength = tanklength;
        TankId = UUID.randomUUID().toString();
        PreferenceUtils.saveHeight(TankId, context);
        PreferenceUtils.saveHeight(String.valueOf(TankHeight), context);
        PreferenceUtils.saveWidth(String.valueOf(Tankwidth), context);
        PreferenceUtils.saveLength(String.valueOf(Tanklength), context);
         DB.insertTankInfo (TankId , TankHeight, Tanklength , Tankwidth, HouseHolder.getUserId(context));
    }

    public static void UpdateHeightWidthLength(double tankHeight, double tankwidth, double tanklength, Context context) {
        TankHeight = tankHeight;
        Tankwidth = tankwidth;
        Tanklength = tanklength;
        PreferenceUtils.saveHeight(String.valueOf(TankHeight), context);
        PreferenceUtils.saveWidth(String.valueOf(Tankwidth), context);
        PreferenceUtils.saveLength(String.valueOf(Tanklength), context);
        DB.updateTankInfo(Tank.getTankId(context) , TankHeight, Tanklength , Tankwidth);

    }


}





