package com.example.app;



import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DBHelper extends SQLiteOpenHelper {
    public DBHelper(Context context) {
        super(context, "dropDB.db", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase DB) {
        DB.execSQL("create Table Housholders(userId TEXT primary key  NOT NULL, householderName TEXT)");
        DB.execSQL("create Table TankInfo(tankId TEXT primary key NOT NULL, tankHeight NUMERIC, tankLength NUMERIC, tankWidth NUMERIC, userId TEXT NOT NULL, FOREIGN KEY (userId) REFERENCES Housholders(userId) )");
        DB.execSQL("create Table WaterState(ID TEXT primary key NOT NULL, waterAmount NUMERIC, dailyCons NUMERIC, waterQuality NUMERIC, date TEXT, tankId TEXT NOT NULL, FOREIGN KEY (tankId) REFERENCES TankInfo(tankId) )");
        DB.execSQL("create Table raspberryPiBoards(raspberryPiBoardId TEXT primary key NOT NULL, configurationId TEXT,tankId TEXT NOT NULL, FOREIGN KEY (tankId) REFERENCES Tanks(tankId) )");
    }

    @Override
    public void onUpgrade(SQLiteDatabase DB, int i, int i1) {
        DB.execSQL("drop Table if exists Housholders");
        DB.execSQL("drop Table if exists TankInfo");
        DB.execSQL("drop Table if exists WaterSate");
        DB.execSQL("drop Table if exists raspberryPiBoards");

    }
            /*Housholders table: insert, update,delete, and get data.*/

    public boolean insertHHData (String userId ,String householderName){
        /*inserts a specific Housholder data */
        SQLiteDatabase DB = this.getWritableDatabase();
        ContentValues contentValues =new ContentValues();
        contentValues.put("userId", userId);
        contentValues.put("householderName", householderName);
        long result = DB.insert("Housholders", null ,contentValues );

        if(result==-1){
            return false;
        }else {
            return true;
        }
    }

    public boolean updateHHData (String userId ,String householderName){
        /*updates a specific Housholder data */
        SQLiteDatabase DB = this.getWritableDatabase();
        ContentValues contentValues =new ContentValues();
        Cursor cursor= DB.rawQuery("Select * from Housholders where userId=?", new String[] {userId});

        if(cursor.getCount()>0){
        contentValues.put("userId", userId);
        contentValues.put("householderName", householderName);

        long result = DB.update("Housholders",contentValues, "userId=?" , new String[] {userId} );

        if(result==-1){
            return false;
        }else {
            return true;
        }}
        return false;}

    public boolean deleteHHData (String userId){
        /*deletes a specific housholder data */

        SQLiteDatabase DB = this.getWritableDatabase();
        Cursor cursor= DB.rawQuery("Select * from Housholders where userId=?", new String[] {userId});

        if(cursor.getCount()>0){
            long result = DB.delete("Housholders", "userId=?", new String[] {userId});

            if(result==-1){
                return false;
            }else {
                return true;
            }
        }
        else {
            return false;
        }

    }

    ///////////////////////////////////////////////////
    public void deleteHHTable ( ){
        /*deletes housholders table */
        SQLiteDatabase DB = this.getWritableDatabase();
        DB.execSQL("drop Table Housholders");

    }


    public Cursor getHHsData (){
        /*retrieves all housholders' data */
        SQLiteDatabase DB = this.getWritableDatabase();
        Cursor cursor= DB.rawQuery("Select * from Housholders ",null);
        return cursor;
    }

    public Cursor getHHData (String userId){
        /*retrieves a specific housholder's data */
        SQLiteDatabase DB = this.getWritableDatabase();
        Cursor cursor= DB.rawQuery("Select * from Housholders where userId=?", new String[] {userId});
        return cursor;
    }

    /*TankInfo table: insert, update,delete, and get data.*/

    public boolean insertTankInfo (String tankId, double tankHeight, double tankLength, double tankWidth, String userId ){

        /*inserts a specific tank data */
        SQLiteDatabase DB = this.getWritableDatabase();
        ContentValues contentValues =new ContentValues();
        contentValues.put("tankId", tankId);
        contentValues.put("tankHeight", tankHeight);
        contentValues.put("tankLength", tankLength);
        contentValues.put("tankWidth", tankWidth);
        contentValues.put("userId", userId);

        long result = DB.insert("TankInfo", null ,contentValues );

        if(result==-1){
            return false;
        }else {
            return true;
        }
    }

    public boolean updateTankInfo (String tankId, double tankHeight, double tankLength, double tankWidth){
        /*updates a specific tank dimensions */
        SQLiteDatabase DB = this.getWritableDatabase();
        ContentValues contentValues =new ContentValues();
        Cursor cursor= DB.rawQuery("Select * from TankInfo where tankId=?", new String[] {tankId});

        if(cursor.getCount()>0){
        contentValues.put("tankHeight", tankHeight);
        contentValues.put("tankLength", tankLength);
        contentValues.put("tankWidth", tankWidth);


            long result = DB.update("TankInfo", contentValues , "tankId=?", new String[] {tankId});

        if(result==-1){
            return false;
        }else {
            return true;
        }
    }
        else {
            return false;
        }

    }



    public boolean deleteTankInfo (String tankId){
        /*deletes a specific tank data */

        SQLiteDatabase DB = this.getWritableDatabase();
        Cursor cursor= DB.rawQuery("Select * from TankInfo where tankId=?", new String[] {tankId});

        if(cursor.getCount()>0){
            long result = DB.delete("TankInfo", "tankId=?", new String[] {tankId});

            if(result==-1){
                return false;
            }else {
                deleteWaterStatesOfTank(tankId); // deletes water states of the tank
                return true;
            }
        }
        else {
            return false;
        }

    }


    public void deleteTankInfoTable (){
        /*  deletes all tanks table  */
        SQLiteDatabase DB = this.getWritableDatabase();
        DB.execSQL("drop Table TankInfo");

    }

    public Cursor getTankInfoTable (){
        /*retrieves all tanks data */
        SQLiteDatabase DB = this.getWritableDatabase();
        Cursor cursor= DB.rawQuery("Select * from TankInfo ",null);
        return cursor;
    }

    public Cursor getTankInfo (String tankId){
        /*retrieves a specific tank data */
        SQLiteDatabase DB = this.getWritableDatabase();
        Cursor cursor= DB.rawQuery("Select * from TankInfo where tankId=?", new String[] {tankId});
        return cursor;
    }


    /*WaterState table: insert, update,delete, and get data.*/

    public boolean insertWaterState (String ID,double waterAmount,double dailyCons ,double waterQuality, String date, String tankId ){

        /*inserts a specific water state*/
        SQLiteDatabase DB = this.getWritableDatabase();
        ContentValues contentValues =new ContentValues();
        contentValues.put("ID", ID);
        contentValues.put("waterAmount", waterAmount);
        contentValues.put("dailyCons", dailyCons);
        contentValues.put("waterQuality", waterQuality);
        contentValues.put("date", date);
        contentValues.put("tankId", tankId);

        long result = DB.insert("WaterState", null ,contentValues );

        if(result==-1){
            return false;
        }else {
            return true;
        }
    }



    public boolean updateWaterState (String ID,double waterAmount,double dailyCons ,double waterQuality){
        /*updates a specific water state */
        SQLiteDatabase DB = this.getWritableDatabase();
        ContentValues contentValues =new ContentValues();
        Cursor cursor= DB.rawQuery("Select * from WaterState where ID=?", new String[] {ID});

        if(cursor.getCount()>0){
            contentValues.put("waterAmount", waterAmount);
            contentValues.put("dailyCons", dailyCons);
            contentValues.put("waterQuality", waterQuality);
            long result = DB.update("WaterState", contentValues , "ID=?",   new String[] {ID});

            if(result==-1){
                return false;
            }else {
                return true;
            }
        }
        else {
            return false;
        }

    }


    public boolean deleteWaterState (String ID){
        /*deletes a specific water state */

        SQLiteDatabase DB = this.getWritableDatabase();
        Cursor cursor= DB.rawQuery("Select * from WaterState  where ID=?", new String[] {ID});

        if(cursor.getCount()>0){
            long result = DB.delete("WaterState ", "ID=?", new String[] {ID});

            if(result==-1){
                return false;
            }else {
                return true;
            }
        }
        else {
            return false;
        }

    }

    public boolean deleteWaterStatesOfTank (String tankId){
        /*deletes all water states for a specific tank */

        SQLiteDatabase DB = this.getWritableDatabase();
        Cursor cursor= DB.rawQuery("Select * from WaterState  where tankId=?", new String[] {tankId});

        if(cursor.getCount()>0){
            long result = DB.delete("WaterState ", "tankId=?", new String[] {tankId});

            if(result==-1){
                return false;
            }else {
                return true;
            }
        }
        else {
            return false;
        }

    }


    public void deleteWaterStateTable (){
        /*  deletes all WaterState table  */
        SQLiteDatabase DB = this.getWritableDatabase();
        DB.execSQL("drop Table WaterState ");

    }

    public Cursor getWaterStateTable (){
        /*retrieves all WaterState table */
        SQLiteDatabase DB = this.getWritableDatabase();
        Cursor cursor= DB.rawQuery("Select * from WaterState  ",null);
        return cursor;
    }

    public Cursor getWaterState (String ID){
        /*retrieves a specific water state */
        SQLiteDatabase DB = this.getWritableDatabase();
        Cursor cursor= DB.rawQuery("Select * from WaterState where ID=?", new String[] {ID});
        return cursor;
    }

    public Cursor getMonthlyCons (String firstday,String lastday){
        /* retrieves water consumption for a specific month */
        SQLiteDatabase DB = this.getWritableDatabase();
        String[] arguments = new String[]{String.valueOf(firstday),String.valueOf(lastday)};
        Cursor cursor= DB.rawQuery("Select dailyCons from WaterState where date Between ?"+" And ?", arguments);
        return cursor;
    }

    public Cursor getLastDate (String tankId){
        /* retrieves the last date a row was inserted for a specific tank */
        SQLiteDatabase DB = this.getWritableDatabase();
        Cursor cursor= DB.rawQuery("SELECT date FROM WaterState  where tankId=? ORDER BY date DESC LIMIT 1", new String[] {tankId});
        return cursor;
    }

    public Cursor getWaterAmount (String ID){
        /*retrieves water amount */
        SQLiteDatabase DB = this.getWritableDatabase();
        Cursor cursor= DB.rawQuery("Select waterAmount from WaterState where ID=?", new String[] {ID});
        return cursor;
    }

    public Cursor getDailyCons (String tankId){
        /*retrieves water amount */
        SQLiteDatabase DB = this.getWritableDatabase();
        Cursor cursor= DB.rawQuery("Select dailyCons from WaterState  where tankId=? ORDER BY date DESC LIMIT 1", new String[] {tankId});
        return cursor;
    }


    /*raspberryPiBoards table: insert, update,delete, and get data.*/

    public boolean insertBoardData (String raspberryPiBoardId ,String configurationId, String tankId){
        /*inserts a specific raspberry pi board data */
        SQLiteDatabase DB = this.getWritableDatabase();
        ContentValues contentValues =new ContentValues();
        contentValues.put("raspberryPiBoardId", raspberryPiBoardId);
        contentValues.put("configurationId", configurationId);
        contentValues.put("tankId", tankId);
        long result = DB.insert("raspberryPiBoards", null ,contentValues );

        if(result==-1){
            return false;
        }else {
            return true;
        }
    }

    public boolean updateBoardData (String raspberryPiBoardId ,String configurationId){
        /*updates a specific raspberry pi board data */
        SQLiteDatabase DB = this.getWritableDatabase();
        ContentValues contentValues =new ContentValues();
        Cursor cursor= DB.rawQuery("Select * from raspberryPiBoards where raspberryPiBoardId=?", new String[] {raspberryPiBoardId});

        if(cursor.getCount()>0){
            contentValues.put("raspberryPiBoardId", raspberryPiBoardId);
            contentValues.put("configurationId", configurationId);

            long result = DB.update("raspberryPiBoards",contentValues, "raspberryPiBoardId=?" , new String[] {raspberryPiBoardId} );

            if(result==-1){
                return false;
            }else {
                return true;
            }}
        return false;}

    public boolean deleteBoardData (String raspberryPiBoardId){
        /*deletes a specific raspberry pi board  data */

        SQLiteDatabase DB = this.getWritableDatabase();
        Cursor cursor= DB.rawQuery("Select * from raspberryPiBoards where raspberryPiBoardId=?", new String[] {raspberryPiBoardId});

        if(cursor.getCount()>0){
            long result = DB.delete("raspberryPiBoards", "raspberryPiBoardId=?", new String[] {raspberryPiBoardId});

            if(result==-1){
                return false;
            }else {
                return true;
            }
        }
        else {
            return false;
        }

    }

    //////////////////////////////////
    public void deleteBoardData (){
        /*  deletes all raspberry pi boards' table  */
        SQLiteDatabase DB = this.getWritableDatabase();
        DB.execSQL("drop Table raspberryPiBoards");

    }

    public Cursor getBoardsTable (){
        /*retrieves raspberry pi boards' data */
        SQLiteDatabase DB = this.getWritableDatabase();
        Cursor cursor= DB.rawQuery("Select * from raspberryPiBoards ",null);
        return cursor;
    }

    public Cursor getBoardData (String raspberryPiBoardId){
        /*retrieves a specific raspberry pi board data */
        SQLiteDatabase DB = this.getWritableDatabase();
        Cursor cursor= DB.rawQuery("Select * from raspberryPiBoards where raspberryPiBoardId=?", new String[] {raspberryPiBoardId});
        return cursor;
    }

    public Cursor getQuery (String query){
        /*executes any query*/
        SQLiteDatabase DB = this.getWritableDatabase();
        Cursor cursor= DB.rawQuery(query, null);
        return cursor;
    }



}
