package com.example.app;

import static com.example.app.set_up.DB;

import android.content.Context;

import java.util.UUID;

public class Board {
    private static String configId;
    private static String RPId;

    public static void setboardID (String configid , Context context) { //call in set up
        configId = configid;
        RPId= UUID.randomUUID().toString();
        PreferenceUtils.saveBoardId(configId,context);
        PreferenceUtils.saveRbId(RPId,context);
        DB.insertBoardData (RPId ,configId , Tank.getTankId(context));
    }

    public static String getConfigId(Context context) {
        return PreferenceUtils.getBoardId(context);
    }



    public static void UpdateConfigId(String configId , Context context) { //call in change setting
        PreferenceUtils.saveBoardId(configId,context);
        RPId=PreferenceUtils.getRbId(context);
        DB.updateBoardData (RPId,configId);
    }


}
